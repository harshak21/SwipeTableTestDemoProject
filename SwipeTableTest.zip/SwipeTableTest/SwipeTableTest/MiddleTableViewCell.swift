//
//  middleTableViewCell.swift
//  SwipeTableTest
//
//  Created by Harsha K on 03/02/17.
//  Copyright © 2017 Harsha.com. All rights reserved.
//

import Foundation
import UIKit

class MiddleTableViewCell: UITableViewCell {
    @IBOutlet weak var middleCellLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
   
}
