//
//  middleTableView.swift
//  SwipeTableTest
//
//  Created by Harsha K on 03/02/17.
//  Copyright © 2017 Harsha.com. All rights reserved.
//

import Foundation
import UIKit

class MiddleTableView: UITableView, UITableViewDataSource, UITableViewDelegate {
    
    var middleNames: [String] = ["India", "bhutan", "Nepal", "Japan", "Canada", "sriLanka"]
    
    var swipe : Bool = false
    var cellNo : Int = 0
    
    override func awakeFromNib() {
        
        self.delegate = self
        self.dataSource = self
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.addGestureRecognizer(swipeRight)
        
        let swipeLEFT = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLEFT.direction = UISwipeGestureRecognizerDirection.left
        self.addGestureRecognizer(swipeLEFT)
    }
    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            let swipeLocation = gesture.location(in: self)
            let swipeIndexPath = self.indexPathForRow(at: swipeLocation)
            switch swipeGesture.direction {
                
            case UISwipeGestureRecognizerDirection.right:
                print("Swiped right")
                self.addToRight(index: swipeIndexPath!)
                self.swipe = true
                
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
                
            case UISwipeGestureRecognizerDirection.left:
                print("Swiped left")
                self.swipe = true
                self.addToLeft(index: swipeIndexPath!)
                
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
                
            default:
                break
            }
        }
    }
    
    func addToLeft(index: IndexPath) {
        UserDefaults.standard.set(middleNames[index.row], forKey: "leftArray")
        middleNames.remove(at: index.row)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "reloadLeft"), object: nil)
        reloadData()
    }
    
    func addToRight(index: IndexPath){
        UserDefaults.standard.set(middleNames[index.row], forKey: "rightArray")
        middleNames.remove(at: index.row)
        reloadData()
        NotificationCenter.default.post(name: NSNotification.Name(rawValue:"reloadRight"), object: nil)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return middleNames.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.swipe == true {
            self.middleNames.remove(at: indexPath.row)
            self.reloadData()
            swipe = false
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "middleCell", for: indexPath)
        cell.textLabel?.text = middleNames[indexPath.row]
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return cell
    }
    
}
