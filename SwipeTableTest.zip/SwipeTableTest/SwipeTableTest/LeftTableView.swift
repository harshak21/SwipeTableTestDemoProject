//
//  leftTableView.swift
//  SwipeTableTest
//
//  Created by Harsha K on 03/02/17.
//  Copyright © 2017 Harsha.com. All rights reserved.
//

import Foundation
import UIKit

class LeftTableView: UITableView, UITableViewDelegate, UITableViewDataSource {
    
    var updatedNames : [String] = []
    
    override func awakeFromNib() {
        self.delegate = self
        self.dataSource = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(LeftTableView.reloadLeftTable), name: NSNotification.Name(rawValue: "reloadLeft"), object: nil)
    }
    
    func reloadLeftTable(){
        updatedNames.append(UserDefaults.standard.object(forKey: "leftArray") as! String)
        reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if updatedNames.isEmpty {
            return 1
        } else {
            return updatedNames.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "leftCell", for: indexPath)
        if updatedNames.isEmpty{
            return cell
        }
        else {
            cell.textLabel?.text = updatedNames[indexPath.row]
            cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            return cell
        }
    }
    
}
