//
//  RightTableView.swift
//  SwipeTableTest
//
//  Created by Harsha K on 03/02/17.
//  Copyright © 2017 Harsha.com. All rights reserved.
//

import Foundation
import UIKit

class RightTableView: UITableView, UITableViewDelegate, UITableViewDataSource {
    
    var updateNames : [String] = []
    
    override func awakeFromNib() {
        self.delegate = self
        self.dataSource = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(RightTableView.reloadRightTable), name: NSNotification.Name(rawValue: "reloadRight"), object: nil)
    }
    
    func reloadRightTable(){
        updateNames.append(UserDefaults.standard.object(forKey: "rightArray") as! String)
        reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if updateNames.isEmpty {
            return 1
        } else {
            return updateNames.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "rightCell", for: indexPath)
        
        if updateNames.isEmpty {
            return cell
        } else {
            cell.textLabel?.text = updateNames[indexPath.row]
            cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            return cell
        }
    }
    
}
