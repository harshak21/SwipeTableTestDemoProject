//
//  leftTableViewCell.swift
//  SwipeTableTest
//
//  Created by Harsha K on 03/02/17.
//  Copyright © 2017 Harsha.com. All rights reserved.
//

import Foundation
import UIKit

class LeftTableViewCell: UITableViewCell {
    
    @IBOutlet weak var label: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
